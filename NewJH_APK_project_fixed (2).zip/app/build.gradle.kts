plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.newjh.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.newjh.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "2.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
