package com.newjh.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pool = Executors.newFixedThreadPool(8)

    private fun isNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Status bar + navigation bar follow the app theme (light = dark icons, dark = light icons). */
    @Suppress("DEPRECATION")
    private fun applyBars(dark: Boolean) {
        val c = Color.parseColor(if (dark) "#101722" else "#FFFFFF")
        window.statusBarColor = c
        window.navigationBarColor = c
        var f = window.decorView.systemUiVisibility
        f = if (dark) {
            f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        } else {
            f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        if (Build.VERSION.SDK_INT >= 26) {
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = f
    }

    /** One network request (GET, or POST when [post] is set) run off the UI thread; result goes back to JS. */
    private fun doRequest(id: Int, url: String, post: String?) {
        pool.execute {
            var ok = 0
            var b64 = ""
            try {
                var u = url
                var conn: HttpURLConnection? = null
                for (i in 0..5) {
                    conn = (URL(u).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 8000
                        readTimeout = 10000
                        instanceFollowRedirects = false
                        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                        setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml,application/rss+xml,*/*")
                        setRequestProperty("Accept-Language", "en-IN,en;q=0.9,hi;q=0.8")
                        if (post != null) {
                            requestMethod = "POST"
                            doOutput = true
                            setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                            outputStream.use { it.write(post.toByteArray()) }
                        }
                    }
                    val c = conn.responseCode
                    if (c in 300..399 && post == null) {
                        val loc = conn.getHeaderField("Location") ?: break
                        u = URL(URL(u), loc).toString()
                        conn.disconnect()
                        continue
                    }
                    break
                }
                if (conn != null && conn.responseCode in 200..299) {
                    val out = ByteArrayOutputStream()
                    conn.inputStream.use { s ->
                        val buf = ByteArray(8192)
                        var total = 0
                        while (total < 3_000_000) { // cap very large pages
                            val n = s.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            total += n
                        }
                    }
                    b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                    ok = 1
                }
            } catch (_: Exception) {
            }
            runOnUiThread {
                if (!isFinishing) web.evaluateJavascript("window.__nf($id,$ok,'$b64')", null)
            }
        }
    }

    inner class Net {
        @JavascriptInterface
        fun get(id: Int, url: String) = doRequest(id, url, null)

        @JavascriptInterface
        fun post(id: Int, url: String, body: String) = doRequest(id, url, body)

        @JavascriptInterface
        fun share(title: String, url: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, title + "\n" + url)
                }
                try { startActivity(Intent.createChooser(i, "Share")) } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun open(url: String) = runOnUiThread { openExternal(url) }

        @JavascriptInterface
        fun bars(dark: Boolean) = runOnUiThread { applyBars(dark) }
    }

    private fun openExternal(url: String?) {
        if (url.isNullOrBlank()) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyBars(isNight())
        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        setContentView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web.settings.apply {
            javaScriptEnabled = true
            textZoom = 100
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            domStorageEnabled = true
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }
        web.setOnTouchListener { _, e -> e.pointerCount > 1 } // block pinch-zoom
        web.addJavascriptInterface(Net(), "NativeNet")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("file:///android_asset/")) return false
                openExternal(u)
                return true
            }
        }
        // window.open / target=_blank links open in the phone's browser
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: Message): Boolean {
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(x: WebView, r: WebResourceRequest): Boolean {
                        openExternal(r.url.toString())
                        x.destroy()
                        return true
                    }
                }
                (m.obj as WebView.WebViewTransport).webView = tmp
                m.sendToTarget()
                return true
            }
        }
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(o: Bundle) {
        super.onSaveInstanceState(o)
        web.saveState(o)
    }

    override fun onDestroy() {
        pool.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
