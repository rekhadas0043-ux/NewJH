package com.newjh.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pool = Executors.newFixedThreadPool(8)

    /** Native network fetch: no CORS limits, no third-party proxy, runs in parallel. */
    inner class Net {
        @JavascriptInterface
        fun get(id: Int, url: String) {
            pool.execute {
                var ok = 0
                var b64 = ""
                try {
                    var u = url
                    var conn: HttpURLConnection? = null
                    for (i in 0..4) {
                        conn = (URL(u).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 8000; readTimeout = 10000
                            instanceFollowRedirects = false
                            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, text/html, */*")
                        }
                        val c = conn.responseCode
                        if (c in 300..399) {
                            val loc = conn.getHeaderField("Location") ?: break
                            u = URL(URL(u), loc).toString(); conn.disconnect(); continue
                        }
                        break
                    }
                    if (conn != null && conn.responseCode in 200..299) {
                        val bytes = conn.inputStream.use { it.readBytes() }
                        b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        ok = 1
                    }
                } catch (_: Exception) {}
                runOnUiThread { web.evaluateJavascript("window.__nf($id,$ok,'$b64')", null) }
            }
        }
    }

    private fun openExternal(url: String?) {
        if (url.isNullOrBlank()) return
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#FFFFFF")
        window.navigationBarColor = Color.parseColor("#FFFFFF")
        web = WebView(this)
        setContentView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web.settings.apply {
            javaScriptEnabled = true
            textZoom = 100
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }
        web.setOnTouchListener { _, e -> e.pointerCount > 1 } // block pinch-zoom
        web.addJavascriptInterface(Net(), "NativeNet")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("file:///android_asset/")) return false
                openExternal(u); return true
            }
        }
        // window.open / target=_blank links open in the phone's browser
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: Message): Boolean {
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(x: WebView, r: WebResourceRequest): Boolean {
                        openExternal(r.url.toString()); x.destroy(); return true
                    }
                }
                (m.obj as WebView.WebViewTransport).webView = tmp
                m.sendToTarget(); return true
            }
        }
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); web.saveState(o) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
